import React, { Component } from 'react'

import './SideBar';
import SideBar from './SideBar';

import MUIDataTable from "mui-datatables";
import ProgressBar from 'react-bootstrap/ProgressBar'

export default class Home extends Component {
    render() {
        const columns = ["Action", "Name", "Status", "Connectors", "Instant", "Public", "Site"];

        const data = [
          [<i className="fas fa-map-marker-alt puple"></i>, "SAP-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
          <div className="connects">
              <div className="first-co">
              <span className="acricle">A</span>
              <strong><i className="fas fa-surprise"></i></strong>
              </div>
              <div className="first-co">
              <span className="acricle">B</span>
              <strong><i className="fas fa-surprise"></i></strong>
              </div>
          </div>,
           <div className="instant-td">
               0/44.2kw
               <ProgressBar variant="info" now={40} />
           </div>, "No", "SAP Labs Caen" ],

[<i className="fas fa-map-marker-alt puple"></i>, "SAP-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
<div className="connects">
    <div className="first-co">
    <span className="acricle">A</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
    <div className="first-co">
    <span className="acricle">B</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
</div>,
 <div className="instant-td">
     0/44.2kw
     <ProgressBar variant="info" now={0} />
 </div>, "No", "SAP Labs Caen" ],

  [<i className="fas fa-map-marker-alt puple"></i>, "SAP-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
  <div className="connects">
      <div className="first-co">
      <span className="acricle">A</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
      <div className="first-co">
      <span className="acricle">B</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
  </div>,
   <div className="instant-td">
       0/44.2kw
       <ProgressBar variant="info" now={80} />
   </div>, "No", "SAP Labs Caen" ],

[<i class="fas fa-map-marker-alt puple"></i>, "SAc-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
<div className="connects">
    <div className="first-co">
    <span className="acricle">A</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
    <div className="first-co">
    <span className="acricle">B</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>

    <div className="first-co">
    <span className="acricle">A</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
    <div className="first-co">
    <span className="acricle">B</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
</div>,
 <div className="instant-td">
     0/44.2kw
     <ProgressBar variant="info" now={100} />
 </div>, "No", "SAc Labs Caen" ],


[<i class="fas fa-map-marker-alt puple"></i>, "SAP-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
  <div className="connects">
      <div className="first-co">
      <span className="acricle">A</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
      <div className="first-co">
      <span className="acricle">B</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
  </div>,
   <div className="instant-td">
       0/44.2kw
       <ProgressBar variant="info" now={80} />
   </div>, "No", "SAP Labs Caen" ],


[<i className="fas fa-map-marker-alt puple"></i>, "SAb-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
  <div className="connects">
      <div className="first-co">
      <span className="acricle">A</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
      <div className="first-co">
      <span className="acricle">B</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
  </div>,
   <div className="instant-td">
       0/44.2kw
       <ProgressBar variant="info" now={80} />
   </div>, "No", "SAb Labs Caen" ],

[<i className="fas fa-map-marker-alt puple"></i>, "SAd-Caen-01", <span className="green"><i class="fas fa-heartbeat"></i> Connected</span> , 
  <div className="connects">
      <div className="first-co">
      <span className="acricle">A</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
      <div className="first-co">
      <span className="acricle">B</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
  </div>,
   <div className="instant-td">
       0/44.2kw
       <ProgressBar variant="info" now={0} />
   </div>, "No", "SAd Labs Caen" ],

[<i className="fas fa-map-marker-alt puple"></i>, "SAd-Caen-01", <span className="green"><i class="fas fa-heartbeat"></i> Connected</span> , 
  <div className="connects">
      <div className="first-co">
      <span className="acricle">A</span>
      <strong><i class="fas fa-surprise"></i></strong>
      </div>
      <div className="first-co">
      <span className="acricle">B</span>
      <strong><i className="fas fa-surprise"></i></strong>
      </div>
  </div>,
   <div className="instant-td">
       0/44.2kw
       <ProgressBar variant="info" now={20} />
   </div>, "No", "SAd Labs Caen" ],

[<i className="fas fa-map-marker-alt puple"></i>, "SAd-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
<div className="connects">
    <div className="first-co">
    <span className="acricle">A</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
    <div className="first-co">
    <span className="acricle">B</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
</div>,
 <div className="instant-td">
     0/44.2kw
     <ProgressBar variant="info" now={100} />
 </div>, "No", "SAd Labs Caen" ],

[<i className="fas fa-map-marker-alt puple"></i>, "SAd-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
<div className="connects">
    <div className="first-co">
    <span className="acricle">A</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
    <div className="first-co">
    <span className="acricle">B</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
</div>,
 <div className="instant-td">
     0/44.2kw
     <ProgressBar variant="info" now={80} />
 </div>, "No", "SAd Labs Caen" ],

[<i className="fas fa-map-marker-alt puple"></i>, "SAd-Caen-01", <span className="green"><i className="fas fa-heartbeat"></i> Connected</span> , 
<div className="connects">
    <div className="first-co">
    <span className="acricle">A</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
    <div className="first-co">
    <span className="acricle">B</span>
    <strong><i className="fas fa-surprise"></i></strong>
    </div>
</div>,
 <div className="instant-td">
     0/44.2kw
     <ProgressBar variant="info" now={80} />
 </div>, "No", "SAd Labs Caen" ],


         
        ];
    
        const options = {
          filterType: "dropdown",
          responsive: "scroll"
        };
    
        return (
            <div className="charing">
                <SideBar/>
                <div className="main-content">
<div className="top-header">
 <span className="stations"> <i class="fas fa-charging-station"></i>   charging Station </span>

</div>
<MUIDataTable 
        title={"Owner"}
        data={data}
        columns={columns}
        options={options}
      />

                </div>
            </div>
        )
    }
}
